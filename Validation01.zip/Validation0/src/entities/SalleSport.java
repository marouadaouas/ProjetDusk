/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.sql.Time;
import java.util.Objects;

/**
 *
 * @author PC
 */
public class SalleSport {
    
    private int id_salle ; 
    private int adresse_salle ; 
    private String nom_salle ; 
    private int num_tel_salle ; 
    private String email_salle ; 
    private Time horaire_ouverture_salle ;
    private Time horaire_fermeture_salle ;
    private int id_resp_salle ;
    //private Adresse a ;
    private String ch1 ;
    private String ch2 ;
    

    public SalleSport(int adresse_salle, String nom_salle, int num_tel_salle, String email_salle, Time horaire_ouverture_salle, Time horaire_fermeture_salle, int id_resp_salle) {
        this.adresse_salle = adresse_salle;
        this.nom_salle = nom_salle;
        this.num_tel_salle = num_tel_salle;
        this.email_salle = email_salle;
        this.horaire_ouverture_salle = horaire_ouverture_salle;
        this.horaire_fermeture_salle = horaire_fermeture_salle;
        this.id_resp_salle = id_resp_salle;
    }

    public SalleSport(int id_salle, int adresse_salle, String nom_salle, int num_tel_salle, String email_salle, Time horaire_ouverture_salle, Time horaire_fermeture_salle, int id_resp_salle) {
        this.id_salle = id_salle;
        this.adresse_salle = adresse_salle;
        this.nom_salle = nom_salle;
        this.num_tel_salle = num_tel_salle;
        this.email_salle = email_salle;
        this.horaire_ouverture_salle = horaire_ouverture_salle;
        this.horaire_fermeture_salle = horaire_fermeture_salle;
        this.id_resp_salle = id_resp_salle;
    }

    public SalleSport() {
    }

    

    public int getId_salle() {
        return id_salle;
    }

    public void setId_salle(int id_salle) {
        this.id_salle = id_salle;
    }

    public int getAdresse_salle() {
        return adresse_salle;
    }

    public void setAdresse_salle(int adresse_salle) {
        this.adresse_salle = adresse_salle;
    }

    public String getNom_salle() {
        return nom_salle;
    }

    public void setNom_salle(String nom_salle) {
        this.nom_salle = nom_salle;
    }

    public int getNum_tel_salle() {
        return num_tel_salle;
    }

    public void setNum_tel_salle(int num_tel_salle) {
        this.num_tel_salle = num_tel_salle;
    }

    public String getEmail_salle() {
        return email_salle;
    }

    public void setEmail_salle(String email_salle) {
        this.email_salle = email_salle;
    }

    public Time getHoraire_ouverture_salle() {
        return horaire_ouverture_salle;
    }

    public void setHoraire_ouverture_salle(Time horaire_ouverture_salle) {
        this.horaire_ouverture_salle = horaire_ouverture_salle;
    }

    public Time getHoraire_fermeture_salle() {
        return horaire_fermeture_salle;
    }

    public void setHoraire_fermeture_salle(Time horaire_fermeture_salle) {
        this.horaire_fermeture_salle = horaire_fermeture_salle;
    }

    public int getId_resp_salle() {
        return id_resp_salle;
    }

    public void setId_resp_salle(int id_resp_salle) {
        this.id_resp_salle = id_resp_salle;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + this.id_salle;
        hash = 97 * hash + this.adresse_salle;
        hash = 97 * hash + Objects.hashCode(this.nom_salle);
        hash = 97 * hash + this.num_tel_salle;
        hash = 97 * hash + Objects.hashCode(this.email_salle);
        hash = 97 * hash + Objects.hashCode(this.horaire_ouverture_salle);
        hash = 97 * hash + Objects.hashCode(this.horaire_fermeture_salle);
        hash = 97 * hash + this.id_resp_salle;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final SalleSport other = (SalleSport) obj;
        if (this.id_salle != other.id_salle) {
            return false;
        }
        if (this.adresse_salle != other.adresse_salle) {
            return false;
        }
        if (this.num_tel_salle != other.num_tel_salle) {
            return false;
        }
        if (this.id_resp_salle != other.id_resp_salle) {
            return false;
        }
        if (!Objects.equals(this.nom_salle, other.nom_salle)) {
            return false;
        }
        if (!Objects.equals(this.email_salle, other.email_salle)) {
            return false;
        }
        if (!Objects.equals(this.horaire_ouverture_salle, other.horaire_ouverture_salle)) {
            return false;
        }
        if (!Objects.equals(this.horaire_fermeture_salle, other.horaire_fermeture_salle)) {
            return false;
        }
        return true;
    }

    public SalleSport(int id_salle, int adresse_salle, String nom_salle, int num_tel_salle, String email_salle, Time horaire_ouverture_salle, Time horaire_fermeture_salle, int id_resp_salle, String ch1, String ch2) {
        this.id_salle = id_salle;
        this.adresse_salle = adresse_salle;
        this.nom_salle = nom_salle;
        this.num_tel_salle = num_tel_salle;
        this.email_salle = email_salle;
        this.horaire_ouverture_salle = horaire_ouverture_salle;
        this.horaire_fermeture_salle = horaire_fermeture_salle;
        this.id_resp_salle = id_resp_salle;
        this.ch1 = ch1;
        this.ch2 = ch2;
    }

    @Override
    public String toString() {
        return "SalleSport{" + "id_salle=" + id_salle + ", adresse_salle=" + adresse_salle + ", nom_salle=" + nom_salle + ", num_tel_salle=" + num_tel_salle + ", email_salle=" + email_salle + ", horaire_ouverture_salle=" + horaire_ouverture_salle + ", horaire_fermeture_salle=" + horaire_fermeture_salle + ", id_resp_salle=" + id_resp_salle + ", ch1=" + ch1 + ", ch2=" + ch2 + '}';
    }

   
   

   
    
    
    
    
    
    
    
    
}
