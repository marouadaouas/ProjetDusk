/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.sql.Time;
import java.util.Objects;

/**
 *
 * @author PC
 */
public class Cours_sport {
    
    private int id ; 
    private String nom_cours ; 
    private Float prix_cours ; 
    private Time heure_cours ; 
    private int id_coach_cours ; 
    private String nom_coach ;

    public Cours_sport() {
    }

    public Cours_sport(int id, String nom_cours, Float prix_cours, Time heure_cours, int id_coach_cours, String nom_coach) {
        this.id = id;
        this.nom_cours = nom_cours;
        this.prix_cours = prix_cours;
        this.heure_cours = heure_cours;
        this.id_coach_cours = id_coach_cours;
        this.nom_coach = nom_coach;
    }

    public Cours_sport(String nom_cours, Float prix_cours, Time heure_cours, int id_coach_cours) {
        this.nom_cours = nom_cours;
        this.prix_cours = prix_cours;
        this.heure_cours = heure_cours;
        this.id_coach_cours = id_coach_cours;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom_cours() {
        return nom_cours;
    }

    public void setNom_cours(String nom_cours) {
        this.nom_cours = nom_cours;
    }

    public Float getPrix_cours() {
        return prix_cours;
    }

    public void setPrix_cours(Float prix_cours) {
        this.prix_cours = prix_cours;
    }

    public Time getHeure_cours() {
        return heure_cours;
    }

    public void setHeure_cours(Time heure_cours) {
        this.heure_cours = heure_cours;
    }

    public int getId_coach_cours() {
        return id_coach_cours;
    }

    public void setId_coach_cours(int id_coach_cours) {
        this.id_coach_cours = id_coach_cours;
    }

    public String getNom_coach() {
        return nom_coach;
    }

    public void setNom_coach(String nom_coach) {
        this.nom_coach = nom_coach;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 17 * hash + this.id;
        hash = 17 * hash + Objects.hashCode(this.nom_cours);
        hash = 17 * hash + Objects.hashCode(this.prix_cours);
        hash = 17 * hash + Objects.hashCode(this.heure_cours);
        hash = 17 * hash + this.id_coach_cours;
        hash = 17 * hash + Objects.hashCode(this.nom_coach);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Cours_sport other = (Cours_sport) obj;
        if (this.id != other.id) {
            return false;
        }
        if (this.id_coach_cours != other.id_coach_cours) {
            return false;
        }
        if (!Objects.equals(this.nom_cours, other.nom_cours)) {
            return false;
        }
        if (!Objects.equals(this.nom_coach, other.nom_coach)) {
            return false;
        }
        if (!Objects.equals(this.prix_cours, other.prix_cours)) {
            return false;
        }
        if (!Objects.equals(this.heure_cours, other.heure_cours)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Cours_sport{" + "id=" + id + ", nom_cours=" + nom_cours + ", prix_cours=" + prix_cours + ", heure_cours=" + heure_cours + ", id_coach_cours=" + id_coach_cours + ", nom_coach=" + nom_coach + '}';
    }
    
    
    
    
}
