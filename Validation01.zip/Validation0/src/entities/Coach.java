/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.Objects;

/**
 *
 * @author PC
 */
public class Coach {
    
    private int id_coach ; 
    private String nom_coach ; 
    private String prenom_coach ; 
    private String job_coach ; 
    private int id_coach_salle ; 
    private String nom_salle ; 

    public Coach(String nom_coach, String prenom_coach, String job_coach, int id_coach_salle) {
        this.nom_coach = nom_coach;
        this.prenom_coach = prenom_coach;
        this.job_coach = job_coach;
        this.id_coach_salle = id_coach_salle;
    }

    public Coach(int id_coach, String nom_coach, String prenom_coach, String job_coach, String nom_salle) {
        this.id_coach = id_coach;
        this.nom_coach = nom_coach;
        this.prenom_coach = prenom_coach;
        this.job_coach = job_coach;
        this.nom_salle = nom_salle;
    }

    public Coach() {
    }

    public int getId_coach() {
        return id_coach;
    }

    public void setId_coach(int id_coach) {
        this.id_coach = id_coach;
    }

    public String getNom_coach() {
        return nom_coach;
    }

    public void setNom_coach(String nom_coach) {
        this.nom_coach = nom_coach;
    }

    public String getPrenom_coach() {
        return prenom_coach;
    }

    public void setPrenom_coach(String prenom_coach) {
        this.prenom_coach = prenom_coach;
    }

    public String getJob_coach() {
        return job_coach;
    }

    public void setJob_coach(String job_coach) {
        this.job_coach = job_coach;
    }

    public int getId_coach_salle() {
        return id_coach_salle;
    }

    public void setId_coach_salle(int id_coach_salle) {
        this.id_coach_salle = id_coach_salle;
    }

    public String getNom_salle() {
        return nom_salle;
    }

    public void setNom_salle(String nom_salle) {
        this.nom_salle = nom_salle;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 53 * hash + this.id_coach;
        hash = 53 * hash + Objects.hashCode(this.nom_coach);
        hash = 53 * hash + Objects.hashCode(this.prenom_coach);
        hash = 53 * hash + Objects.hashCode(this.job_coach);
        hash = 53 * hash + this.id_coach_salle;
        hash = 53 * hash + Objects.hashCode(this.nom_salle);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Coach other = (Coach) obj;
        if (this.id_coach != other.id_coach) {
            return false;
        }
        if (this.id_coach_salle != other.id_coach_salle) {
            return false;
        }
        if (!Objects.equals(this.nom_coach, other.nom_coach)) {
            return false;
        }
        if (!Objects.equals(this.prenom_coach, other.prenom_coach)) {
            return false;
        }
        if (!Objects.equals(this.job_coach, other.job_coach)) {
            return false;
        }
        if (!Objects.equals(this.nom_salle, other.nom_salle)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Coach{" + "id_coach=" + id_coach + ", nom_coach=" + nom_coach + ", prenom_coach=" + prenom_coach + ", job_coach=" + job_coach + ", id_coach_salle=" + id_coach_salle + ", nom_salle=" + nom_salle + '}';
    }
    
    
    
    
    
}
