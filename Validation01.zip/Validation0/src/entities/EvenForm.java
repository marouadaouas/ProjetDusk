/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.sql.Date;
import java.util.Objects;
import javax.print.attribute.standard.DateTimeAtCompleted;

/**
 *
 * @author PC
 */

//public  enum Type {"sportif","culturelle";};
public class EvenForm {
    
    
    //public  enum Type {"sportif","culturelle";}
    private int id_event ; 
    private String nom_event ; 
    private String genre_event ; 
    private Date date_event ; 
    private String  lieu_event ; 
    private int duree_event ; 
    private String type_event ;

    public EvenForm() {
    }

    public EvenForm(String nom_event, String genre_event, Date date_event, String lieu_event, int duree_event, String type_event) {
        this.nom_event = nom_event;
        this.genre_event = genre_event;
        this.date_event = date_event;
        this.lieu_event = lieu_event;
        this.duree_event = duree_event;
        this.type_event = type_event;
    }

    public EvenForm(int id_event, String nom_event, String genre_event, Date date_event, String lieu_event, int duree_event, String type_event) {
        this.id_event = id_event;
        this.nom_event = nom_event;
        this.genre_event = genre_event;
        this.date_event = date_event;
        this.lieu_event = lieu_event;
        this.duree_event = duree_event;
        this.type_event = type_event;
    }

    public int getId_event() {
        return id_event;
    }

    public void setId_event(int id_event) {
        this.id_event = id_event;
    }

    public String getNom_event() {
        return nom_event;
    }

    public void setNom_event(String nom_event) {
        this.nom_event = nom_event;
    }

    public String getGenre_event() {
        return genre_event;
    }

    public void setGenre_event(String genre_event) {
        this.genre_event = genre_event;
    }

    public Date getDate_event() {
        return date_event;
    }

    public void setDate_event(Date date_event) {
        this.date_event = date_event;
    }

    public String getLieu_event() {
        return lieu_event;
    }

    public void setLieu_event(String lieu_event) {
        this.lieu_event = lieu_event;
    }

    public int getDuree_event() {
        return duree_event;
    }

    public void setDuree_event(int duree_event) {
        this.duree_event = duree_event;
    }

    public String getType_event() {
        return type_event;
    }

    public void setType_event(String type_event) {
        this.type_event = type_event;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 47 * hash + this.id_event;
        hash = 47 * hash + Objects.hashCode(this.nom_event);
        hash = 47 * hash + Objects.hashCode(this.genre_event);
        hash = 47 * hash + Objects.hashCode(this.date_event);
        hash = 47 * hash + Objects.hashCode(this.lieu_event);
        hash = 47 * hash + this.duree_event;
        hash = 47 * hash + Objects.hashCode(this.type_event);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final EvenForm other = (EvenForm) obj;
        if (this.id_event != other.id_event) {
            return false;
        }
        if (this.duree_event != other.duree_event) {
            return false;
        }
        if (!Objects.equals(this.nom_event, other.nom_event)) {
            return false;
        }
        if (!Objects.equals(this.genre_event, other.genre_event)) {
            return false;
        }
        if (!Objects.equals(this.lieu_event, other.lieu_event)) {
            return false;
        }
        if (!Objects.equals(this.type_event, other.type_event)) {
            return false;
        }
        if (!Objects.equals(this.date_event, other.date_event)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "EvenForm{" + "id_event=" + id_event + ", nom_event=" + nom_event + ", genre_event=" + genre_event + ", date_event=" + date_event + ", lieu_event=" + lieu_event + ", duree_event=" + duree_event + ", type_event=" + type_event + '}';
    }
    
    
    
}
