/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.sql.Date;
import java.util.Objects;

/**
 *
 * @author PC
 */
public class Rdv {
    private int id_rdv ; 
    private Date date_rdv ; 
    private int id_lieu ; 
    private String etat_rdv ; 
    private int id_user ; 
    private String nom_user ; 

    public Rdv() {
    }

    public Rdv(int id_rdv, Date date_rdv, int id_lieu, String etat_rdv, int id_user, String nom_user) {
        this.id_rdv = id_rdv;
        this.date_rdv = date_rdv;
        this.id_lieu = id_lieu;
        this.etat_rdv = etat_rdv;
        this.id_user = id_user;
        this.nom_user = nom_user;
    }

    public Rdv(Date date_rdv, int id_lieu, String etat_rdv, int id_user) {
        this.date_rdv = date_rdv;
        this.id_lieu = id_lieu;
        this.etat_rdv = etat_rdv;
        this.id_user = id_user;
    }

    public int getId_rdv() {
        return id_rdv;
    }

    public void setId_rdv(int id_rdv) {
        this.id_rdv = id_rdv;
    }

    public Date getDate_rdv() {
        return date_rdv;
    }

    public void setDate_rdv(Date date_rdv) {
        this.date_rdv = date_rdv;
    }

    public int getId_lieu() {
        return id_lieu;
    }

    public void setId_lieu(int id_lieu) {
        this.id_lieu = id_lieu;
    }

    public String getEtat_rdv() {
        return etat_rdv;
    }

    public void setEtat_rdv(String etat_rdv) {
        this.etat_rdv = etat_rdv;
    }

    public int getId_user() {
        return id_user;
    }

    public void setId_user(int id_user) {
        this.id_user = id_user;
    }

    public String getNom_user() {
        return nom_user;
    }

    public void setNom_user(String nom_user) {
        this.nom_user = nom_user;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 59 * hash + this.id_rdv;
        hash = 59 * hash + Objects.hashCode(this.date_rdv);
        hash = 59 * hash + this.id_lieu;
        hash = 59 * hash + Objects.hashCode(this.etat_rdv);
        hash = 59 * hash + this.id_user;
        hash = 59 * hash + Objects.hashCode(this.nom_user);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Rdv other = (Rdv) obj;
        if (this.id_rdv != other.id_rdv) {
            return false;
        }
        if (this.id_lieu != other.id_lieu) {
            return false;
        }
        if (this.id_user != other.id_user) {
            return false;
        }
        if (!Objects.equals(this.etat_rdv, other.etat_rdv)) {
            return false;
        }
        if (!Objects.equals(this.nom_user, other.nom_user)) {
            return false;
        }
        if (!Objects.equals(this.date_rdv, other.date_rdv)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Rdv{" + "id_rdv=" + id_rdv + ", date_rdv=" + date_rdv + ", id_lieu=" + id_lieu + ", etat_rdv=" + etat_rdv + ", id_user=" + id_user + ", nom_user=" + nom_user + '}';
    }

    
    
    
    
}
