/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import entities.Coach;
import entities.SalleSport;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.DataSource;

/**
 *
 * @author PC
 */
public class ServiceCoach {
    
     public Connection con=DataSource.getInstance().getConnection();
    public Statement ste;
    
    
    public ServiceCoach()
    {
        try {
            ste=con.createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(ServiceAdresse.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void AjouterCoach (Coach c ) throws SQLException
    {
        String req=" INSERT INTO `coach`(`nom_coach`, `prenom_coach`, `job_coach`, `id_coach_salle`) "
                + "VALUES (?,?,?,?)";
        PreparedStatement pre= con.prepareStatement(req);
        
        pre.setString(1,c.getNom_coach());
        pre.setString(2,c.getPrenom_coach()); 
        pre.setString(3,c.getJob_coach());
        pre.setInt(4,c.getId_coach_salle());
        
        
        pre.executeUpdate();
        
        System.out.println("coach Ajoutée");
    }
    
    public  void updateCoach ( Coach c,int id)throws SQLException
        {
              
                 String req = " UPDATE `coach` SET `nom_coach`=?,`prenom_coach`=?,`job_coach`=?,`id_coach_salle`=? WHERE id_coach=?";
                 PreparedStatement pre= con.prepareStatement(req);
                
                  pre.setString(1,c.getNom_coach());
                  pre.setString(2,c.getPrenom_coach()); 
                  pre.setString(3,c.getJob_coach());
                  pre.setInt(4,c.getId_coach_salle()) ;
                 pre.setInt(5,id);
                 pre.executeUpdate();
                 System.out.println("coach mise à jour"); 
        } 
    
    public  void supprimerCoach( int id) throws SQLException
        {
                 String req = "DELETE FROM `coach` WHERE id_salle="+id;
                 Statement pre=con.createStatement();
                 pre.executeUpdate(req);
                  System.out.println("coach Supprimée");
        }
    
    public  List<Coach> selectCoach() throws SQLException
      {
       List<Coach> list=new ArrayList<>();
         
            String req="SELECT  `id_coach`, `nom_coach`, `prenom_coach`, `job_coach`, "

    + "                    salle.nom_salle"

    + "                    FROM coach Inner JOIN salle_de_sport salle on salle.id_salle=coach.id_coach_salle";
            PreparedStatement ste= con.prepareStatement(req);
            ResultSet result=ste.executeQuery();
            
            while(result.next())
            {
            Coach c;
           c = new Coach (result.getInt("id_coach"),result.getString("nom_coach")
                   ,result.getString("prenom_coach"),result.getString("job_coach"),result.getString("salle.nom_salle"));
            list.add(c);
            }
           
       return list;
      }
    
}
