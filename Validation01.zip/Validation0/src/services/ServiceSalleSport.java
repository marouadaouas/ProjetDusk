/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import entities.Adresse;
import entities.SalleSport;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.DataSource;

/**
 *
 * @author PC
 */
public class ServiceSalleSport {
    
    public Connection con=DataSource.getInstance().getConnection();
    public Statement ste;
    
    
    public ServiceSalleSport()
    {
        try {
            ste=con.createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(ServiceAdresse.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void AjouterSalleSport (SalleSport s ) throws SQLException
    {
        String req="INSERT INTO `salle_de_sport`(`adresse_salle`, `nom_salle`, `num_tel_salle`, `email_salle`, `horaire_ouverture_salle`, `horaire_fermeture_salle`, `id_resp_salle`) "
                + "VALUES (?,?,?,?,?,?,?)";
        PreparedStatement pre= con.prepareStatement(req);
        
        pre.setInt(1,s.getAdresse_salle());
        pre.setString(2,s.getNom_salle()); 
        pre.setInt(3,s.getNum_tel_salle());
        pre.setString(4,s.getEmail_salle());
        pre.setTime(5,s.getHoraire_ouverture_salle());
        pre.setTime(6,s.getHoraire_fermeture_salle());
        pre.setInt(7,s.getId_resp_salle());
        
        
        pre.executeUpdate();
        
        System.out.println("salle Ajoutée");
    }
    
    public  void updateSalleSport( SalleSport s,int id)throws SQLException
        {
              
                 String req = "UPDATE `salle_de_sport` SET `adresse_salle`=?,`nom_salle`=? ,`num_tel_salle`=?,`email_salle`=?,`horaire_ouverture_salle`=?,`horaire_fermeture_salle`=?,`id_resp_salle`=? WHERE id_salle=?";
                 PreparedStatement pre= con.prepareStatement(req);
                
                  pre.setInt(1,s.getAdresse_salle());
                  pre.setString(2,s.getNom_salle()); 
                  pre.setInt(3,s.getNum_tel_salle());
                  pre.setString(4,s.getEmail_salle());
                  pre.setTime(5,s.getHoraire_ouverture_salle());
                  pre.setTime(6,s.getHoraire_fermeture_salle());
                  pre.setInt(7,s.getId_resp_salle());
                 pre.setInt(8,id);
                 pre.executeUpdate();
                 System.out.println("salle mise à jour"); 
        } 
    
    public  void supprimerSalleSport( int id) throws SQLException
        {
                 String req = "DELETE FROM `salle_de_sport` WHERE id_salle="+id;
                 Statement pre=con.createStatement();
                 pre.executeUpdate(req);
                  System.out.println("Salle Supprimée");
        }
    
    public  List<SalleSport> selectsalleSport() throws SQLException
      {
       List<SalleSport> list=new ArrayList<>();
         
            String req="SELECT `id_salle`, `adresse_salle`, `nom_salle`, `num_tel_salle`, `email_salle`, `horaire_ouverture_salle`, `horaire_fermeture_salle`, `id_resp_salle`, \n"

    + "                    ad.titre ,ad.ville"

    + "                    FROM salle_de_sport Inner JOIN adresses ad on ad.id_adresses=salle_de_sport.adresse_salle";
            PreparedStatement ste= con.prepareStatement(req);
            ResultSet result=ste.executeQuery();
            
            while(result.next())
            {
            SalleSport s;
           s = new SalleSport(result.getInt("id_salle"),result.getInt("adresse_salle")
                   ,result.getString("nom_salle"),result.getInt("num_tel_salle"),result.getString("email_salle"),result.getTime("horaire_ouverture_salle"),result.getTime("horaire_fermeture_salle"),result.getInt("id_resp_salle"),result.getString("ad.titre"),result.getString("ad.ville"));
            list.add(s);
            }
           
       return list;
      }
    
}
