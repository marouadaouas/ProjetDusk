/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import entities.Adresse;
import entities.EvenForm;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.DataSource;

/**
 *
 * @author PC
 */
public class ServiceEvenForm {
    
    public Connection con=DataSource.getInstance().getConnection();
    public Statement ste;
    
    
    public ServiceEvenForm()
    {
        try {
            ste=con.createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(ServiceAdresse.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    public void AjouterEvenForm (EvenForm e ) throws SQLException
    {
        String req="INSERT INTO `even_form`( `nom_event`, `genre_event`, `date_event`, `lieu_event`, `duree_event`, `type_event`) "
                + "VALUES (?,?,?,?,?,?)";
        PreparedStatement pre= con.prepareStatement(req);
        
        pre.setString(1,e.getNom_event());
        pre.setString(2,e.getGenre_event()); 
        pre.setDate(3,e.getDate_event());
        pre.setString(4,e.getLieu_event());
        pre.setInt(5,e.getDuree_event());
        pre.setString(6, e.getType_event());
        
        pre.executeUpdate();
        
        System.out.println("EvenForm Ajoutée");
    }
 
    
    public  void updateEvenForm( EvenForm e,int id)throws SQLException
        {
              
                 String req = "UPDATE `even_form` SET `nom_event`=?,`genre_event`=?,`date_event`=?,`lieu_event`=?,`duree_event`=?,`type_event`=? where id_event=?";
                 PreparedStatement pre= con.prepareStatement(req);
                
                  pre.setString(1,e.getNom_event());
                  pre.setString(2,e.getGenre_event()); 
                  pre.setDate(3,e.getDate_event());
                  pre.setString(4,e.getLieu_event());
                  pre.setInt(5,e.getDuree_event());
                  pre.setString(6, e.getType_event());
                 pre.setInt(7,id);
                 pre.executeUpdate();
                 System.out.println("event mise à jour"); 
        } 
           
    
    
     public  void supprimerEventForm( int id) throws SQLException
        {
                 String req = "DELETE FROM `even_form` WHERE id_event="+id;
                 Statement pre=con.createStatement();
                 pre.executeUpdate(req);
                  System.out.println("event Supprimée");
        }
    
     
      public  List<EvenForm> selectEvenForm() throws SQLException
      {
       List<EvenForm> list=new ArrayList<>();
         
            String req="SELECT * FROM even_form";
            PreparedStatement ste= con.prepareStatement(req);
            ResultSet result=ste.executeQuery();
            
            while(result.next())
            {
            EvenForm e= new EvenForm(result.getInt("id_event"),result.getString("nom_event")
                    ,result.getString("genre_event"),result.getDate("date_event"),result.getString("lieu_event"),result.getInt("duree_event"),result.getString("type_event"));
            list.add(e);
            }
           
       return list;
      }
    
}
