/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import entities.Cours_sport;
import entities.Rdv;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.DataSource;

/**
 *
 * @author PC
 */
public class ServiceRdv {
    
    public Connection con=DataSource.getInstance().getConnection();
    public Statement ste;
    
    
    public ServiceRdv()
    {
        try {
            ste=con.createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(ServiceAdresse.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void AjouterRdv (Rdv r ) throws SQLException
    {
        String req=" INSERT INTO `rdv`(`date_rdv`, `id_lieu`, `etat_rdv`, `id_user`) "
                + "VALUES (?,?,?,?)";
        PreparedStatement pre= con.prepareStatement(req);
        
        pre.setDate(1,r.getDate_rdv());
        pre.setInt(2,r.getId_lieu()); 
        pre.setString(3,r.getEtat_rdv());
        pre.setInt(4,r.getId_user());
        
        
        pre.executeUpdate();
        
        System.out.println("RDV Ajoutée");
    }
    
    public  void updateRdv ( Rdv r,int id)throws SQLException
        {
              
                 String req = " UPDATE `rdv` SET `date_rdv`=?,`id_lieu`=?,`etat_rdv`=?,`id_user`=? WHERE id_rdv=?";
                 PreparedStatement pre= con.prepareStatement(req);
                
                  pre.setDate(1,r.getDate_rdv());
                  pre.setInt(2,r.getId_lieu()); 
                  pre.setString(3,r.getEtat_rdv());
                  pre.setInt(4,r.getId_user());
                 pre.setInt(5,id);
                 pre.executeUpdate();
                 System.out.println("RDV mise à jour"); 
        } 
    
    public  void supprimerRdv( int id) throws SQLException
        {
                 String req = "DELETE FROM `rdv` WHERE id_rdv="+id;
                 Statement pre=con.createStatement();
                 pre.executeUpdate(req);
                  System.out.println("RDV Supprimée");
        }
    
    public  List<Rdv> selectRdv() throws SQLException
      {
       List<Rdv> list=new ArrayList<>();
         
            String req="SELECT   `id_rdv`, `date_rdv`, `id_lieu`, `etat_rdv`, `id_user`, "

    + "                    u.nom"

    + "                    FROM rdv Inner JOIN utilisateur u on u.id_u=rdv.id_user";
            PreparedStatement ste= con.prepareStatement(req);
            ResultSet result=ste.executeQuery();
            
            while(result.next())
            {
            Rdv r;
           r = new Rdv(result.getInt("id_rdv"),result.getDate("date_rdv")
                   ,result.getInt("id_lieu"),result.getString("etat_rdv"),result.getInt("id_user"),result.getString("u.nom"));
            list.add(r);
            }
           
       return list;
      }
}
