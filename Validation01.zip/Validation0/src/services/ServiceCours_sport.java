/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import entities.Coach;
import entities.Cours_sport;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.DataSource;

/**
 *
 * @author PC
 */
public class ServiceCours_sport {
    
     public Connection con=DataSource.getInstance().getConnection();
    public Statement ste;
    
    
    public ServiceCours_sport()
    {
        try {
            ste=con.createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(ServiceAdresse.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void AjouterCoursSport (Cours_sport c ) throws SQLException
    {
        String req=" INSERT INTO `cours_sport`(`nom_cours`, `prix_cours`, `heure_cours`, `id_coach_cours`) "
                + "VALUES (?,?,?,?)";
        PreparedStatement pre= con.prepareStatement(req);
        
        pre.setString(1,c.getNom_cours());
        pre.setFloat(2,c.getPrix_cours()); 
        pre.setTime(3,c.getHeure_cours());
        pre.setInt(4,c.getId_coach_cours());
        
        
        pre.executeUpdate();
        
        System.out.println("cour Ajoutée");
    }
    
    public  void updateCoursSport ( Cours_sport c,int id)throws SQLException
        {
              
                 String req = " UPDATE `cours_sport` SET `nom_cours`=?,`prix_cours`=?,`heure_cours`=?,`id_coach_cours`=? WHERE id_cours=?";
                 PreparedStatement pre= con.prepareStatement(req);
                
                  pre.setString(1,c.getNom_cours());
                  pre.setFloat(2,c.getPrix_cours()); 
                  pre.setTime(3,c.getHeure_cours());
                  pre.setInt(4, c.getId_coach_cours());
                 pre.setInt(5,id);
                 pre.executeUpdate();
                 System.out.println("cour mise à jour"); 
        } 
    
    public  void supprimerCoursSport( int id) throws SQLException
        {
                 String req = "DELETE FROM `cours_sport` WHERE id_cours="+id;
                 Statement pre=con.createStatement();
                 pre.executeUpdate(req);
                  System.out.println("cours Supprimée");
        }
    
    public  List<Cours_sport> selectCoursSport() throws SQLException
      {
       List<Cours_sport> list=new ArrayList<>();
         
            String req="SELECT  `id_cours`, `nom_cours`, `prix_cours`, `heure_cours`, `id_coach_cours`, "

    + "                    co.nom_coach"

    + "                    FROM cours_sport Inner JOIN coach co on co.id_coach=cours_sport.id_coach_cours";
            PreparedStatement ste= con.prepareStatement(req);
            ResultSet result=ste.executeQuery();
            
            while(result.next())
            {
            Cours_sport c;
           c = new Cours_sport (result.getInt("id_cours"),result.getString("nom_cours")
                   ,result.getFloat("prix_cours"),result.getTime("heure_cours"),result.getInt("id_coach_cours"),result.getString("co.nom_coach"));
            list.add(c);
            }
           
       return list;
      }
    
}
