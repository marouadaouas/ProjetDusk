/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package validation0;

import entities.Adresse;
import entities.Coach;
import entities.Cours_sport;
import entities.EvenForm;
import entities.Rdv;
import entities.SalleSport;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.util.logging.Level;
import java.util.logging.Logger;
import services.ServiceAdresse;
import services.ServiceSalleSport ;
import services.ServiceCoach ;
import services.ServiceCours_sport ;
import services.ServiceEvenForm ;
import services.ServiceRdv ;
/**
 *
 * @author Kais
 */
public class Validation0 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //AjouterAdresse(new Adresse("Cabinet DR nobody","Ariana","rue nowhere",2040));
       
        
       // updatePersonne(p,2);
        //supprimerPersonne(p);
        //selectAdresse().forEach(System.out::println);
        
        
         Adresse a= new Adresse("Cabinet DR nobody","Ariana","rue nowhere",2040);
         Adresse b= new Adresse("Cabinet DR noone","Rades","rue somewhere",2400);
         Adresse c= new Adresse("Ca DR noone","Rad","rue here",2899);
         Adresse d= new Adresse("Cabinet  noone","es","rue where",1452);
         Adresse e= new Adresse("Cabinet DR ","des"," somewhere",1895);
         SalleSport s1;
        s1 = new SalleSport(1, "californiagym", 2121, "aaaaaaa", new Time(10, 0, 0), new Time(00, 0, 0), 1);
        
        SalleSport s2 ; 
        s2 = new SalleSport(1, "duo", 2121, "bbbbb", new Time(10, 0, 0), new Time(18, 0, 0), 2);
        
        Coach c1 = new Coach("foufou", "fachfouch", "mus", 2) ;
        Coach c2 = new Coach("rico", "loulou", "dance", 4) ;
        
        Cours_sport cour1 ;
        cour1 = new Cours_sport("dance", 20.f, new Time(17, 30, 0), 2);
        
        Cours_sport cour2 ;
        cour2 = new Cours_sport("taybo", 15.f, new Time(12, 30, 0), 1);
        
        EvenForm ev1 = new EvenForm("jjj", "ffff", new Date(2018, 10, 2), "kkkk", 2, "jhhkl"); 
        EvenForm ev2 = new EvenForm("1111", "222f", new Date(2018, 5, 2), "jjjj", 0, "jhgfgh"); 
        
        Rdv r1 = new Rdv(new Date(2019, 1, 12), 4, "verifie", 1) ;
        Rdv r2 = new Rdv(new Date(2000, 5, 5), 4, "non verifie", 3) ;
        
        
         
        ServiceAdresse sa=new ServiceAdresse();
        ServiceSalleSport ss = new ServiceSalleSport() ;
        ServiceCoach sc = new ServiceCoach() ;
        ServiceCours_sport scs = new ServiceCours_sport() ;
        ServiceEvenForm sev = new ServiceEvenForm();
        ServiceRdv sr = new ServiceRdv() ;
        
        
        
       
        try {
            
            /********** adresse********************** */
            //sa.AjouterAdresse(c);
            //sa.AjouterAdresse(d);
            //sa.AjouterAdresse(e);
            
           // sa.updateAdresse(e,1);
           // sa.supprimerAdresse(3);
            //sa.selectAdresse().forEach(System.out::println);
            
            /******** salle de sport ***************/
            
            //ss.AjouterSalleSport(s2);
            //ss.updateSalleSport(s2,2);
            //ss.supprimerSalleSport(3);
            //ss.selectsalleSport().forEach(System.out::println);
            
            /******* coach ******/
           // sc.AjouterCoach(c2);
          // sc.updateCoach(c1, 3);
          // sc.selectCoach().forEach(System.out::println);
          
          /******* cours ********/ 
          //scs.AjouterCoursSport(cour1);
          //scs.AjouterCoursSport(cour2);
          //scs.updateCoursSport(cour2, 3);
          //scs.selectCoursSport().forEach(System.out::println);
          
          /**** event ****/
         // sev.AjouterEvenForm(ev2);
          //sev.AjouterEvenForm(ev1);
          //sev.updateEvenForm(ev2, 2);
          //sev.selectEvenForm().forEach(System.out::println);
          
          /******RDV ********/ 
          //sr.AjouterRdv(r1);
          //sr.AjouterRdv(r1);
          //sr.AjouterRdv(r2);
          
          //sr.updateRdv(r2, 1);
          sr.selectRdv().forEach(System.out::println);
          
          
            
            
            
        } catch (SQLException ex) {
            Logger.getLogger(Validation0.class.getName()).log(Level.SEVERE, null, ex);
        }
      
        
    }
    
}
