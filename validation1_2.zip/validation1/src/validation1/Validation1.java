/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package validation1;
import entites.Fiche_medicale;
import entites.Cabinet;
import entites.Emploi;
import entites.Maladie;
import entites.Travail;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.util.logging.Level;
import java.util.logging.Logger;
import services.ServiceCabinet;
import services.ServiceEmploi;
import services.ServiceFiche_medicale;
import services.ServiceMaladie;
import services.ServiceTravail;

/**
 *
 * @author khoulouud
 */
public class Validation1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        
       
        
        
    
    
    // travail temchi bl id auto inc 
    // maladie jawha behi
    //emploi temchi
    // fiche medicale / update
    // cabinet/ update
        try {
           // *****************************tavail*********************************/
           //ServiceTravail st = new ServiceTravail();
           //Travail a =new Travail(8,2,3,4);
        //Travail b =new Travail(9,2,3,4);
        // Travail e =new Travail(6,9,1);
           
// st.AjouterTravail(a);
          
            //st.updateTravail(a,2);
             //st.AjouterTravail(b);
            // st.supprimerTravail(9);
            
            //st.AjouterTravail(e);
            //st.updateTravail(e,10);
           // st.supprimerTravail(10);
            /****************************emploi****************************************/ 
           
    
   //  ServiceEmploi se = new ServiceEmploi();
    //  Emploi z= new Emploi("secritaire",8,"full time job");
     // Emploi x= new Emploi("coach2",8,"full time job");
          // se.AjouterEmploi(z);
          // se.updateEmploi(x, 1);
           //se.supprimerEmploi(1);
          // se.selectEmploi().forEach(System.out::println);
             //st.selectTravail().forEach(System.out::println);
             
             
             
        /****************************Maladie****************************************/  
        
          //  ServiceMaladie sm = new ServiceMaladie();
             //Maladie m =new Maladie("","","");
     //   Maladie m =new Maladie("mal1","yeux","trait1");
     //   Maladie l =new Maladie("mal2","nez","trait2");
      //  Maladie x1 =new Maladie("mal3","nez1","trait3");
            
             //sm.AjouterMaladie(m);
             //sm.AjouterMaladie(l);
            // sm.AjouterMaladie(x1);
            // sm.updateMaladie(m, 2);
             //sm.selectMaladie().forEach(System.out::println);
             //sm.supprimerMaladie(3);
             
            // sm.selectMaladie().forEach(System.out::println);
   /***************************** cabinet*********************************/
             // ajout Cabinet c = new Cabinet(1,25441994,10,11,2);
              //mise a jour
                      Cabinet c1 = new Cabinet(01,25441994,new Time(9,15,0),new Time(17,30,0),3);
                       Cabinet c2 = new Cabinet(01,25448696,new Time(9,15,0),new Time(18,30,0),2);
              ServiceCabinet sc = new ServiceCabinet();
             sc.AjouterCabinet(c1);
             sc.AjouterCabinet(c2);
            
             sc.selectCabinet().forEach(System.out::println);
            // sc.updateCabinet(c1,5);
             //sc.supprimerCabinet(2);
             
             
             //sc.selectCabinet().forEach(System.out::println);
              
       /**************************fiche medicale*******************************************/
                    //Date d1 = new Date(01/01/2018);
                  //  Fiche_medicale fm = new Fiche_medicale("femme", 1, 2, "o+",5,"oui", "oui", new Date(2018, 1, 12), 20, 90, 90, "oui",2);
                   // Fiche_medicale fm = new Fiche_medicale("homme", 1, 2, "o+",5,"oui", "oui", d1, 20, 90, 90, "oui");
                   ServiceFiche_medicale sfm= new ServiceFiche_medicale();
                    //sfm.AjouterFiche_medicale(fm);
                  // sfm.updateFiche_medicale(fm,6);
                  //sfm.supprimerFiche_medicale(3);
                // sfm.selectFiche_medicale().forEach(System.out::println);
                  // fiche medicale ajout supp list ken update
   /*******************************************/
               
        } catch (SQLException ex) {
            Logger.getLogger(Validation1.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
        
        
        
        
        
        
        
        
        
    }
    
        
        
    }
    

