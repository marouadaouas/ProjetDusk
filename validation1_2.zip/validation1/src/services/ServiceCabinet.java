/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;


import entites.Cabinet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.DataSource;

/**
 *
 * @author khoulouud
 */
public class ServiceCabinet {
    public Connection con=DataSource.getInstance().getConnection();
    public Statement ste;
    
    
    public ServiceCabinet()
    {
        try {
            ste=con.createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(ServiceTravail.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

 public void AjouterCabinet (Cabinet a ) throws SQLException
    {
        String req="INSERT INTO `cabinet`(`adresse_cabinet`, `num_tel_cabinet`, `horaire_ouverture_cabinet`"
                + ", `horaire_fermeture_cabinet`, `id_resp_cabinet`)"
                + "VALUES (?,?,?,?,?)";
        PreparedStatement pre= con.prepareStatement(req);
        
       
        
        pre.setInt(1,a.getAdresse_cabinet()); 
        pre.setLong(2,a.getNum_tel_cabinet());
        pre.setTime(3,a.getHoraire_ouverture_cabinet());
        pre.setTime(4,a.getHoraire_fermeture_cabinet());
        pre.setInt(5,a.getId_resp_cabinet()); 
        
        pre.executeUpdate();
       
        
        System.out.println("cabinet AjoutÃ©e");
        
    }
    
    
    public  void updateCabinet( Cabinet a,int id)throws SQLException
        {
              
                 String req = "UPDATE `cabinet` SET `adresse_cabinet`=?,`num_tel_cabinet`=?,`horaire_ouverture_cabinet`=?,`horaire_fermeture_cabinet`=?,`id_resp_cabinet`=? WHERE `id_cabinet`=? ";
                 PreparedStatement pre= con.prepareStatement(req);
                
                 
                //pre.setInt(1,a.getAdresse_cabinet()); 
                pre.setInt(1,a.getAdresse_cabinet());
                pre.setLong(2,a.getNum_tel_cabinet());
                pre.setTime(3,a.getHoraire_ouverture_cabinet());
                pre.setTime(4,a.getHoraire_fermeture_cabinet());
                pre.setInt(5,a.getId_resp_cabinet());
               pre.setInt(6,id);
                pre.executeUpdate();
                 System.out.println("Cabinet mise Ã  jour"); 

}
 
    public  void supprimerCabinet( int id) throws SQLException
        {
                 String req = "DELETE FROM `cabinet` WHERE id_cabinet="+id;
                 Statement pre=con.createStatement();
                 pre.executeUpdate(req);
                  System.out.println("id_cabinet SupprimÃ©e");
        }

    public  List<Cabinet> selectCabinet() throws SQLException
      {
       List<Cabinet> list=new ArrayList<>();
         
            String req="SELECT * FROM cabinet";
            PreparedStatement ste= con.prepareStatement(req);
            ResultSet result=ste.executeQuery();
            
            while(result.next())
            {
            Cabinet a= new Cabinet (result.getInt("id_cabinet"),result.getInt("adresse_cabinet")
                    ,result.getLong("num_tel_cabinet"),result.getTime("horaire_ouverture_cabinet")
                    ,result.getTime("horaire_fermeture_cabinet"),result.getInt("id_resp_cabinet"));
            list.add(a);
            }
           
       return list;
      }







}
