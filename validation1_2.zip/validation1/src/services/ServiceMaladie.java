/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;


import entites.Maladie;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.DataSource;

/**
 *
 * @author khoulouud
 */
public class ServiceMaladie {
    
    public Connection con=DataSource.getInstance().getConnection();
    public Statement ste;
    public ServiceMaladie()
    {
         try {
            ste=con.createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(ServiceTravail.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

 public void AjouterMaladie (Maladie a ) throws SQLException
    {
        String req="INSERT INTO `maladie`(`nom_maladie`, `description_maladie`, `traitement`)"
                + "VALUES (?,?,?)";
        PreparedStatement pre= con.prepareStatement(req);
        
       
        
        pre.setString(1,a.getNom_maladie()); 
        pre.setString(2,a.getDescription_maladie());
        pre.setString(3,a.getTraitement());
        
        pre.executeUpdate();
       
        
        System.out.println("maladie AjoutÃ©e");
        
    }
    
    
    public  void updateMaladie( Maladie a,int id)throws SQLException
        {
              
                 String req = "UPDATE `maladie` SET `nom_maladie`=?,`description_maladie`=?,`traitement`=? where `id_maladie`=?";
                 PreparedStatement pre= con.prepareStatement(req);
                
                 
                pre.setString(1,a.getNom_maladie()); 
                pre.setString(2,a.getDescription_maladie());
                pre.setString(3,a.getTraitement());
                pre.setInt(4,id);
                pre.executeUpdate();
                 System.out.println("maladie mise Ã  jour"); 

}
    
    
    
    public  void supprimerMaladie( int id) throws SQLException
        {
                 String req = "DELETE FROM `emploi` WHERE id_emploi="+id;
                 Statement pre=con.createStatement();
                 pre.executeUpdate(req);
                  System.out.println("Maladie SupprimÃ©e");
        }

    public  List<Maladie> selectMaladie() throws SQLException
      {
       List<Maladie> list=new ArrayList<>();
         
            String req="SELECT * FROM maladie";
            PreparedStatement ste= con.prepareStatement(req);
            ResultSet result=ste.executeQuery();
            
            while(result.next())
            {
            Maladie a= new Maladie (result.getInt("id_maladie"),result.getString("nom_maladie")
                    ,result.getString("description_maladie"),result.getString("traitement"));
            list.add(a);
            }
           
       return list;
      }








}
