/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import entites.Emploi;
import entites.Travail;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.DataSource;

/**
 *
 * @author khoulouud
 */
public class ServiceEmploi {
    
    public Connection con=DataSource.getInstance().getConnection();
    public Statement ste;
    
    
    public ServiceEmploi()
    {
        try {
            ste=con.createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(ServiceTravail.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void AjouterEmploi (Emploi a ) throws SQLException
    {
        String req="INSERT INTO `emploi`(`libelle`, `id_travail`, `description_travail`)"
                + "VALUES (?,?,?)";
        PreparedStatement pre= con.prepareStatement(req);
        
       
        
        pre.setString(1,a.getLibelle()); 
        pre.setInt(2,a.getId_travail());
        pre.setString(3,a.getDescription_travail());
        
        pre.executeUpdate();
       
        
        System.out.println("Emploi AjoutÃ©e");
        
    }
    
    
    public  void updateEmploi( Emploi a,int id)throws SQLException
        {
              
                 String req = "UPDATE `emploi` SET `libelle`=?,"
                         + "`id_travail`=?,`description_travail`=? where `id_emploi`=?";
                 PreparedStatement pre= con.prepareStatement(req);
                
                 
                pre.setString(1,a.getLibelle()); 
                pre.setInt(2,a.getId_travail());
                pre.setString(3,a.getDescription_travail());
                pre.setInt(4,id);
                pre.executeUpdate();
                 System.out.println("emploi mise Ã  jour"); 

}
    
    
    
    public  void supprimerEmploi( int id) throws SQLException
        {
                 String req = "DELETE FROM `emploi` WHERE id_emploi="+id;
                 Statement pre=con.createStatement();
                 pre.executeUpdate(req);
                  System.out.println("emploi SupprimÃ©e");
        }

    public  List<Emploi> selectEmploi() throws SQLException
      {
       List<Emploi> list=new ArrayList<>();
         
            String req="SELECT * FROM emploi";
            PreparedStatement ste= con.prepareStatement(req);
            ResultSet result=ste.executeQuery();
            
            while(result.next())
            {
            Emploi a= new Emploi (result.getInt("id_emploi"),result.getString("libelle")
                    ,result.getInt("id_travail"),result.getString("description_travail"));
            list.add(a);
            }
           
       return list;
      }
    
    
    
    
    
    
    
    
    
}
