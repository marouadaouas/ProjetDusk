/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;


import java.sql.Time;
import java.util.Objects;

/**
 *
 * @author khoulouud
 */
public class Cabinet {
    private int id_cabinet;
    private int adresse_cabinet;
    private long num_tel_cabinet;
    private Time horaire_ouverture_cabinet;
    private Time horaire_fermeture_cabinet;
    private int id_resp_cabinet;

    public Cabinet(int id_cabinet, int adresse_cabinet, long num_tel_cabinet, Time horaire_ouverture_cabinet, Time horaire_fermeture_cabinet, int id_resp_cabinet) {
        this.id_cabinet = id_cabinet;
        this.adresse_cabinet = adresse_cabinet;
        this.num_tel_cabinet = num_tel_cabinet;
        this.horaire_ouverture_cabinet = horaire_ouverture_cabinet;
        this.horaire_fermeture_cabinet = horaire_fermeture_cabinet;
        this.id_resp_cabinet = id_resp_cabinet;
    }

    public Cabinet(int adresse_cabinet, long num_tel_cabinet, Time horaire_ouverture_cabinet, Time horaire_fermeture_cabinet, int id_resp_cabinet) {
        this.adresse_cabinet = adresse_cabinet;
        this.num_tel_cabinet = num_tel_cabinet;
        this.horaire_ouverture_cabinet = horaire_ouverture_cabinet;
        this.horaire_fermeture_cabinet = horaire_fermeture_cabinet;
        this.id_resp_cabinet = id_resp_cabinet;
    }

    public Cabinet(long num_tel_cabinet, Time horaire_ouverture_cabinet, Time horaire_fermeture_cabinet) {
        this.num_tel_cabinet = num_tel_cabinet;
        this.horaire_ouverture_cabinet = horaire_ouverture_cabinet;
        this.horaire_fermeture_cabinet = horaire_fermeture_cabinet;
    }

    
    
    
    
    
    
    
    
    
    
    
    public int getId_cabinet() {
        return id_cabinet;
    }

    public void setId_cabinet(int id_cabinet) {
        this.id_cabinet = id_cabinet;
    }

    public int getAdresse_cabinet() {
        return adresse_cabinet;
    }

    public void setAdresse_cabinet(int adresse_cabinet) {
        this.adresse_cabinet = adresse_cabinet;
    }

    public long getNum_tel_cabinet() {
        return num_tel_cabinet;
    }

    public void setNum_tel_cabinet(long num_tel_cabinet) {
        this.num_tel_cabinet = num_tel_cabinet;
    }

    public Time getHoraire_ouverture_cabinet() {
        return horaire_ouverture_cabinet;
    }

    public void setHoraire_ouverture_cabinet(Time horaire_ouverture_cabinet) {
        this.horaire_ouverture_cabinet = horaire_ouverture_cabinet;
    }

    public Time getHoraire_fermeture_cabinet() {
        return horaire_fermeture_cabinet;
    }

    public void setHoraire_fermeture_cabinet(Time horaire_fermeture_cabinet) {
        this.horaire_fermeture_cabinet = horaire_fermeture_cabinet;
    }

    public int getId_resp_cabinet() {
        return id_resp_cabinet;
    }

    public void setId_resp_cabinet(int id_resp_cabinet) {
        this.id_resp_cabinet = id_resp_cabinet;
    }

    @Override
    public String toString() {
        return "Cabinet{" + "id_cabinet=" + id_cabinet + ", adresse_cabinet=" + adresse_cabinet + ", num_tel_cabinet=" + num_tel_cabinet + ", horaire_ouverture_cabinet=" + horaire_ouverture_cabinet + ", horaire_fermeture_cabinet=" + horaire_fermeture_cabinet + ", id_resp_cabinet=" + id_resp_cabinet + '}';
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 31 * hash + this.id_cabinet;
        hash = 31 * hash + this.adresse_cabinet;
        hash = 31 * hash + (int) (this.num_tel_cabinet ^ (this.num_tel_cabinet >>> 32));
        hash = 31 * hash + Objects.hashCode(this.horaire_ouverture_cabinet);
        hash = 31 * hash + Objects.hashCode(this.horaire_fermeture_cabinet);
        hash = 31 * hash + this.id_resp_cabinet;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Cabinet other = (Cabinet) obj;
        if (this.id_cabinet != other.id_cabinet) {
            return false;
        }
        if (this.adresse_cabinet != other.adresse_cabinet) {
            return false;
        }
        if (this.num_tel_cabinet != other.num_tel_cabinet) {
            return false;
        }
        if (this.id_resp_cabinet != other.id_resp_cabinet) {
            return false;
        }
        if (!Objects.equals(this.horaire_ouverture_cabinet, other.horaire_ouverture_cabinet)) {
            return false;
        }
        if (!Objects.equals(this.horaire_fermeture_cabinet, other.horaire_fermeture_cabinet)) {
            return false;
        }
        return true;
    }

   
    

   
    
    
}
