/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import entities.Astuces;
import entities.Pharmacie;
import entities.Utilisateur;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.DataSource;

/**
 *
 * @author Kais
 */
public class ServiceAstuces {
	
	 public Connection con=DataSource.getInstance().getConnection();
    public Statement ste;
    
    
    public ServiceAstuces()
    {
        try {
            ste=con.createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(ServiceAstuces.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
	
	
	public void AjouterAstuces (Astuces a ) throws SQLException
    {
        String req="INSERT INTO `astuces`(`libelle`, `description_astuces`, `id_user`) VALUES (?,?,?)";
        PreparedStatement pre= con.prepareStatement(req);
        
        pre.setString(1,a.getLibelle());
        pre.setString(2,a.getDescription_astuces()); 
        pre.setInt(3,a.getId_user());
       
        pre.executeUpdate();
        
        System.out.println("Astuces Ajoutée");
    }
 
    
    public  void updateAstuces( Astuces a,int id)throws SQLException
        {
              
                 String req = "UPDATE `astuces` SET `libelle`=?,`description_astuces`=?,`id_user`=? WHERE `id_astuces`=?";
                 PreparedStatement pre= con.prepareStatement(req);
                
				 pre.setString(1,a.getLibelle());
				 pre.setString(2,a.getDescription_astuces()); 
				 pre.setInt(3,a.getId_user());
			     pre.setInt(4,id);
			     
				 
                 pre.executeUpdate();
                 System.out.println("Astuces mise à jour"); 
        } 
           
    
    
     public  void supprimerAstuces( int id) throws SQLException
        {
                 String req = "DELETE FROM `Astuces` WHERE id_astuces="+id;
                 Statement pre=con.createStatement();
                 pre.executeUpdate(req);
                  System.out.println("Pharmacie Supprimée");
        }
    
     
      public  List<Astuces> selectAstuces() throws SQLException
      {
       List<Astuces> list=new ArrayList<>();
         
            String req="SELECT `libelle`, `description_astuces`, `id_user`, ut.* FROM `astuces`"
					+ "Inner JOIN utilisateur ut on ut.id_u=astuces.id_user ";
            PreparedStatement ste= con.prepareStatement(req);
            ResultSet result=ste.executeQuery();
			
            Utilisateur u;
			ServiceUtilisateur s=new ServiceUtilisateur();
            while(result.next())
            {
            Astuces a= new Astuces (result.getString("libelle"),
				result.getString("description_astuces"), 
				result.getInt("id_user"),
				u= s.findById(result.getInt("adresse_prest"))
			);
            list.add(a);
            }
           
       return list;
      }
}
