/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import entities.Adresse;
import entities.Pharmacie;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.DataSource;

/**
 *
 * @author Kais
 */
public class ServicePharmacie {
	
	
	 public Connection con=DataSource.getInstance().getConnection();
    public Statement ste;
    
    
    public ServicePharmacie()
    {
        try {
            ste=con.createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(ServicePharmacie.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
	
	
	
	public void AjouterPharmacie (Pharmacie p ) throws SQLException
    {
        String req="INSERT INTO `pharmacie`(`nom_pharma`, `adresse_pharma`, `num_tel_pharma`,"
				+ " `email_pharma`, `horaire_ouverture_pharma`, `horaire_fermeture_pharma`, `id_resp_pharma`)"
				+ " VALUES (?,?,?,?,?,?,?)";
        PreparedStatement pre= con.prepareStatement(req);
        
        pre.setString(1,p.getNom_pharma());
        pre.setInt(2,p.getAdresse_pharma()); 
        pre.setInt(3,p.getNum_tel_pharma());
        pre.setString(4,p.getEmail_pharma());
		pre.setTime(5,p.getHoraire_ouverture_pharma());
        pre.setTime(6,p.getHoraire_fermeture_pharma()); 
        pre.setInt(7,p.getId_resp_pharma());
     
        
        pre.executeUpdate();
        
        System.out.println("Pharmacie Ajoutée");
    }
 
    
    public  void updatePharmacie( Pharmacie p,int id)throws SQLException
        {
              
                 String req = "UPDATE `pharmacie` SET `nom_pharma`=?,`adresse_pharma`=?,`num_tel_pharma`=?"
						 + ",`email_pharma`=?,`horaire_ouverture_pharma`=?,`horaire_fermeture_pharma`=?"
						 + ",`id_resp_pharma`=? WHERE `id_pharma`=?";
                 PreparedStatement pre= con.prepareStatement(req);
                
				 pre.setString(1,p.getNom_pharma());
				 pre.setInt(2,p.getAdresse_pharma()); 
				 pre.setInt(3,p.getNum_tel_pharma());
			     pre.setString(4,p.getEmail_pharma());
			     pre.setTime(5,p.getHoraire_ouverture_pharma());
			     pre.setTime(6,p.getHoraire_fermeture_pharma()); 
			     pre.setInt(7,p.getId_resp_pharma());
				 pre.setInt(8,id);
				 
                 pre.executeUpdate();
                 System.out.println("Pharmacie mise à jour"); 
        } 
           
    
    
     public  void supprimerPharmacie( int id) throws SQLException
        {
                 String req = "DELETE FROM `Pharmacie` WHERE id_pharma="+id;
                 Statement pre=con.createStatement();
                 pre.executeUpdate(req);
                  System.out.println("Pharmacie Supprimée");
        }
    
     
      public  List<Pharmacie> selectPharmacie() throws SQLException
      {
       List<Pharmacie> list=new ArrayList<>();
         
            String req="SELECT * FROM Pharmacie";
            PreparedStatement ste= con.prepareStatement(req);
            ResultSet result=ste.executeQuery();
            
            while(result.next())
            {
            Pharmacie p= new Pharmacie (result.getString("Nom_pharma"),
				result.getInt("getAdresse_pharma"), 
				result.getInt("getNum_tel_pharma"),
			    result.getString("getEmail_pharma"),
			    result.getTime("getHoraire_ouverture_pharma"),
			    result.getTime("getHoraire_fermeture_pharma"),
			    result.getInt("getId_resp_pharma"));
            list.add(p);
            }
           
       return list;
      }
}
