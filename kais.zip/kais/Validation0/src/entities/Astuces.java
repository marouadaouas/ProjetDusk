/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.Objects;

/**
 *
 * @author Kais
 */
public class Astuces {
	private int  id_astuces;
	private String libelle;
	private String description_astuces;
	private int  id_user;
	private Utilisateur user;

	public Astuces(int id_astuces, String libelle, String description_astuces, int id_user) {
		this.id_astuces = id_astuces;
		this.libelle = libelle;
		this.description_astuces = description_astuces;
		this.id_user = id_user;
	}

	public Astuces(String libelle, String description_astuces, int id_user) {
		this.libelle = libelle;
		this.description_astuces = description_astuces;
		this.id_user = id_user;
	}

	public Astuces(String libelle, String description_astuces, Utilisateur user) {
		this.libelle = libelle;
		this.description_astuces = description_astuces;
		this.user = user;
	}

	public Astuces(String libelle, String description_astuces, int id_user, Utilisateur user) {
		this.libelle = libelle;
		this.description_astuces = description_astuces;
		this.id_user = id_user;
		this.user = user;
	}
	
	

	public int getId_astuces() {
		return id_astuces;
	}

	public void setId_astuces(int id_astuces) {
		this.id_astuces = id_astuces;
	}

	public String getLibelle() {
		return libelle;
	}

	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}

	public String getDescription_astuces() {
		return description_astuces;
	}

	public void setDescription_astuces(String description_astuces) {
		this.description_astuces = description_astuces;
	}

	public int getId_user() {
		return id_user;
	}

	public void setId_user(int id_user) {
		this.id_user = id_user;
	}

	@Override
	public int hashCode() {
		int hash = 5;
		hash = 19 * hash + this.id_astuces;
		hash = 19 * hash + Objects.hashCode(this.libelle);
		hash = 19 * hash + Objects.hashCode(this.description_astuces);
		hash = 19 * hash + this.id_user;
		return hash;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final Astuces other = (Astuces) obj;
		if (this.id_astuces != other.id_astuces) {
			return false;
		}
		if (this.id_user != other.id_user) {
			return false;
		}
		if (!Objects.equals(this.libelle, other.libelle)) {
			return false;
		}
		if (!Objects.equals(this.description_astuces, other.description_astuces)) {
			return false;
		}
		return true;
	}

	
	
	
	
}
