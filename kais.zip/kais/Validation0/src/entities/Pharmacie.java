/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.sql.Time;
import java.util.Objects;

/**
 *
 * @author Kais
 */
public class Pharmacie {
	private int id_pharma;
	private String nom_pharma;
	private int adresse_pharma;
	private int num_tel_pharma;
	private String email_pharma;
	private Time horaire_ouverture_pharma;
	private Time horaire_fermeture_pharma;
	private int id_resp_pharma;

	public Pharmacie(int id_pharma, String nom_pharma, int adresse_pharma, int num_tel_pharma, String email_pharma, Time horaire_ouverture_pharma, Time horaire_fermeture_pharma, int id_resp_pharma) {
		this.id_pharma = id_pharma;
		this.nom_pharma = nom_pharma;
		this.adresse_pharma = adresse_pharma;
		this.num_tel_pharma = num_tel_pharma;
		this.email_pharma = email_pharma;
		this.horaire_ouverture_pharma = horaire_ouverture_pharma;
		this.horaire_fermeture_pharma = horaire_fermeture_pharma;
		this.id_resp_pharma = id_resp_pharma;
	}

	public Pharmacie(String nom_pharma, int adresse_pharma, int num_tel_pharma, String email_pharma, Time horaire_ouverture_pharma, Time horaire_fermeture_pharma, int id_resp_pharma) {
		this.nom_pharma = nom_pharma;
		this.adresse_pharma = adresse_pharma;
		this.num_tel_pharma = num_tel_pharma;
		this.email_pharma = email_pharma;
		this.horaire_ouverture_pharma = horaire_ouverture_pharma;
		this.horaire_fermeture_pharma = horaire_fermeture_pharma;
		this.id_resp_pharma = id_resp_pharma;
	}

	public int getId_pharma() {
		return id_pharma;
	}

	public void setId_pharma(int id_pharma) {
		this.id_pharma = id_pharma;
	}

	public String getNom_pharma() {
		return nom_pharma;
	}

	public void setNom_pharma(String nom_pharma) {
		this.nom_pharma = nom_pharma;
	}

	public int getAdresse_pharma() {
		return adresse_pharma;
	}

	public void setAdresse_pharma(int adresse_pharma) {
		this.adresse_pharma = adresse_pharma;
	}

	public int getNum_tel_pharma() {
		return num_tel_pharma;
	}

	public void setNum_tel_pharma(int num_tel_pharma) {
		this.num_tel_pharma = num_tel_pharma;
	}

	public String getEmail_pharma() {
		return email_pharma;
	}

	public void setEmail_pharma(String email_pharma) {
		this.email_pharma = email_pharma;
	}

	public Time getHoraire_ouverture_pharma() {
		return horaire_ouverture_pharma;
	}

	public void setHoraire_ouverture_pharma(Time horaire_ouverture_pharma) {
		this.horaire_ouverture_pharma = horaire_ouverture_pharma;
	}

	public Time getHoraire_fermeture_pharma() {
		return horaire_fermeture_pharma;
	}

	public void setHoraire_fermeture_pharma(Time horaire_fermeture_pharma) {
		this.horaire_fermeture_pharma = horaire_fermeture_pharma;
	}

	public int getId_resp_pharma() {
		return id_resp_pharma;
	}

	public void setId_resp_pharma(int id_resp_pharma) {
		this.id_resp_pharma = id_resp_pharma;
	}

	@Override
	public int hashCode() {
		int hash = 3;
		hash = 53 * hash + this.id_pharma;
		hash = 53 * hash + Objects.hashCode(this.nom_pharma);
		hash = 53 * hash + this.adresse_pharma;
		hash = 53 * hash + this.num_tel_pharma;
		hash = 53 * hash + Objects.hashCode(this.email_pharma);
		hash = 53 * hash + Objects.hashCode(this.horaire_ouverture_pharma);
		hash = 53 * hash + Objects.hashCode(this.horaire_fermeture_pharma);
		hash = 53 * hash + this.id_resp_pharma;
		return hash;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		final Pharmacie other = (Pharmacie) obj;
		if (this.id_pharma != other.id_pharma) {
			return false;
		}
		if (this.adresse_pharma != other.adresse_pharma) {
			return false;
		}
		if (this.num_tel_pharma != other.num_tel_pharma) {
			return false;
		}
		if (this.id_resp_pharma != other.id_resp_pharma) {
			return false;
		}
		if (!Objects.equals(this.nom_pharma, other.nom_pharma)) {
			return false;
		}
		if (!Objects.equals(this.email_pharma, other.email_pharma)) {
			return false;
		}
		if (!Objects.equals(this.horaire_ouverture_pharma, other.horaire_ouverture_pharma)) {
			return false;
		}
		if (!Objects.equals(this.horaire_fermeture_pharma, other.horaire_fermeture_pharma)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "Pharmacie{" + "id_pharma=" + id_pharma + ", nom_pharma=" + nom_pharma + ", adresse_pharma=" + adresse_pharma + ", num_tel_pharma=" + num_tel_pharma + ", email_pharma=" + email_pharma + ", horaire_ouverture_pharma=" + horaire_ouverture_pharma + ", horaire_fermeture_pharma=" + horaire_fermeture_pharma + ", id_resp_pharma=" + id_resp_pharma + '}';
	}
	
	
	
}
