/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package validation0;

import entities.Adresse;
import entities.Prestataire_service;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import services.ServiceAdresse;
import services.ServicePrestataire_service;
/**
 *
 * @author Kais
 */
public class Validation0 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       
         Adresse a= new Adresse("Cabinet DR nobody","Ariana","rue nowhere",2040);
      //   Adresse b= new Adresse("Cabinet DR noone","Rades","rue somewhere",2400);
       //  Adresse c= new Adresse("Ca DR noone","Rad","rue here",2899);
       //  Adresse d= new Adresse("Cabinet  noone","es","rue where",1452);
      ////   Adresse e= new Adresse("Cabinet DR ","des"," somewhere",1895);
         Prestataire_service p=new Prestataire_service("esm_prest", "prenom_prest",45,28282828,"email_prest",
                 "login_prest", "mdp_prest"," enligne_prest","etat_prest","fonction","specialite",7);
		 Prestataire_service p1=new Prestataire_service("ltr", "kais",21,28662966,"stuff@mail.com",
                 "login", "password"," online","etat_prest","fonction","specialite",8);
         
        ServiceAdresse sa=new ServiceAdresse();
        ServicePrestataire_service sps=new ServicePrestataire_service();
        
       
        try {
           // sa.AjouterAdresse(c);
           // sa.AjouterAdresse(d);
           // sa.AjouterAdresse(e);
            
           // sa.updateAdresse(b,7);
            //sa.supprimerAdresse(6);
            //sa.selectAdresse().forEach(System.out::println);
           
           //sps.AjouterPrestataire_service(p);
		  // sps.AjouterPrestataire_service(p1);
		 // sps.selectPrestataire_service().forEach(System.out::println);
		 
		 System.out.println(sa.findByAdresse("Cabinet DR noone","Rades","rue somewhere",2400));
		  
        } catch (SQLException ex) {
            Logger.getLogger(Validation0.class.getName()).log(Level.SEVERE, null, ex);
        }
      
        
    }
    
}
