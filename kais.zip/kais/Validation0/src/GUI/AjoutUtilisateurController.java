/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import entities.Adresse;
import entities.Utilisateur;
import java.net.URL;
import java.sql.SQLException;
import java.sql.Time;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import services.ServiceAdresse;
import services.ServiceUtilisateur;

/**
 * FXML Controller class
 *
 * @author Kais
 */
public class AjoutUtilisateurController implements Initializable {
	
ObservableList<Adresse> listA = FXCollections.observableArrayList();
	@FXML
	private TextField TfNom;
	@FXML
	private TextField TfPrenom;
	@FXML
	private TextField TfAge;
	@FXML
	private TextField TfEmail;
	@FXML
	private TextField TfNTelephone;
	@FXML
	private TextField TfLogin;
	@FXML
	private TextField TfPassword;
	@FXML
	private TextField TfNumero;
	@FXML
	private TextField TfRue;
	@FXML
	private TextField TfVille;
	@FXML
	private TextField TfCodePostal;
	@FXML
	private TableColumn<?, ?> TvNumero;
	@FXML
	private TableColumn<?, ?> TvVille;
	@FXML
	private TableColumn<?, ?> TvRue;
	@FXML
	private TableColumn<?, ?> TvCode;
	@FXML
	private TableView<Adresse> TableAdresses;

	/**
	 * Initializes the controller class.
	 */
	@Override
	public void initialize(URL url, ResourceBundle rb) {
		// TODO
		
		initColumns();
	try {
		loadCovList();
	} catch (SQLException ex) {
		Logger.getLogger(AjoutUtilisateurController.class.getName()).log(Level.SEVERE, null, ex);
	}
		
	}	
	
	
	private void initColumns(){
	 
		TvNumero.setCellValueFactory(new PropertyValueFactory<>("titre"));
		TvVille.setCellValueFactory(new PropertyValueFactory<>("ville"));
		TvRue.setCellValueFactory(new PropertyValueFactory<>("rue"));
		TvCode.setCellValueFactory(new PropertyValueFactory<>("code_postal"));
			
	}
	 private void loadCovList() throws SQLException {
        //listCov.clear();
        ServiceAdresse sa=new ServiceAdresse();
       listA=sa.selectAdresse();
       TableAdresses.setItems(listA);

    }

	@FXML
	private void Inscription(ActionEvent event) throws SQLException {
		try {
		
			if (TfNom.getText().equals("") || TfAge.getText().equals("") || TfPrenom.getText().equals("") 
				|| TfEmail.getText().equals("")|| TfNTelephone.getText().equals("")|| TfLogin.getText().equals("")
				|| TfPassword.getText().equals("")|| TfNumero.getText().equals("")|| TfRue.getText().equals("")
				|| TfVille.getText().equals("")|| TfCodePostal.getText().equals(""))
        {
					Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setTitle("Erreur!!");
			alert.setHeaderText("Champs vides !");
			alert.setContentText("Verifiez tout vos champs !?!");
			alert.showAndWait();
		}
		else
		{
		int codep= Integer.parseInt(TfCodePostal.getText());
		int age=Integer.parseInt(TfAge.getText());
		long num=Integer.parseInt(TfNTelephone.getText());
		int id=0;
			
		Adresse a=new Adresse(TfNumero.getText(),TfVille.getText(), TfRue.getText(),codep);
		ServiceAdresse sa=new ServiceAdresse();
		sa.AjouterAdresse(a);
		        
		id=sa.findByAdresse(TfNumero.getText(),TfVille.getText(), TfRue.getText(),codep);
		
		
		Utilisateur u=new Utilisateur(TfNom.getText(),TfPrenom.getText(),age,TfEmail.getText(),num,TfLogin.getText(),TfPassword.getText(),"","",id,a);
		ServiceUtilisateur su=new ServiceUtilisateur();
		su.AjouterUtilisateur(u);
		
		TfNom.clear();
		TfPrenom.clear();
		TfAge.clear();
		TfEmail.clear();
		TfNTelephone.clear();
		TfLogin.clear();
		TfPassword.clear();
		TfNumero.clear();
		TfRue.clear();
		TfVille.clear();
		TfCodePostal.clear();
		/*
		Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
		alert.setTitle("Confirmation");
		alert.setHeaderText("Confirmation");
		alert.setContentText("Faire l'inscription ?");

		Optional<ButtonType> result = alert.showAndWait();
		if (result.get() == ButtonType.OK){
		    // ... user chose OK
		} else {
		   // ... user chose CANCEL or closed the dialog
		}*/
			
		/*Alert alerte = new Alert(Alert.AlertType.INFORMATION);
		
        alerte.setTitle("Utilisateur ajoutée!!");
        alerte.setHeaderText(null);
		alerte.setContentText(u.toString());
        alerte.showAndWait();*/
		
		}
		
		     
        } catch (SQLException ex) {
            Logger.getLogger(AjoutUtilisateurController.class.getName()).log(Level.SEVERE, null, ex);
        }
	
}

	@FXML
	private void RemplirAdresse(MouseEvent event) {
	}
	
}
