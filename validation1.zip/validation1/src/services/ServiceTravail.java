/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;
import entites.Travail;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.DataSource;

/**
 *
 * @author khoulouud
 */
public class ServiceTravail {
    
    public Connection con=DataSource.getInstance().getConnection();
    public Statement ste;
    
    
    public ServiceTravail()
    {
        try {
            ste=con.createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(ServiceTravail.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    public void AjouterTravail (Travail a ) throws SQLException
    {
        String req="INSERT INTO `travail`(`id_salle_trav`, `id_centre_trav`, `id_cab_trav`)"
                + "VALUES (?,?,?)";
        PreparedStatement pre= con.prepareStatement(req);
        
       // pre.setInt(1,a.getId_trav());
        //pre.setInt(2,a.getId_salle_trav()); 
        //pre.setInt(3,a.getId_centre_trav());
        //pre.setInt(4,a.getId_cab_trav());
        
        pre.setInt(1,a.getId_salle_trav()); 
        pre.setInt(2,a.getId_centre_trav());
        pre.setInt(3,a.getId_cab_trav());
        pre.executeUpdate();
        
        System.out.println("Travail AjoutÃ©e");
    }
    
    public  void updateTravail( Travail a,int id)throws SQLException
        {
              
                 String req = "UPDATE `travail` SET `id_salle_trav`=?,`id_centre_trav`=?,`id_cab_trav`=? where id_trav=?";
                 PreparedStatement pre= con.prepareStatement(req);
                
                 
                 pre.setInt(1,a.getId_salle_trav()); 
                 pre.setInt(2,a.getId_centre_trav());
                 pre.setInt(3,a.getId_cab_trav());
                 pre.setInt(4,id);
                 pre.executeUpdate();
                 System.out.println("Travail mise Ã  jour"); 

}
    public  void supprimerTravail( int id) throws SQLException
        {
                 String req = "DELETE FROM `travail` WHERE id_trav="+id;
                 Statement pre=con.createStatement();
                 pre.executeUpdate(req);
                  System.out.println("Travail SupprimÃ©e");
        }

    public  List<Travail> selectTravail() throws SQLException
      {
       List<Travail> list=new ArrayList<>();
         
            String req="SELECT * FROM travail";
            PreparedStatement ste= con.prepareStatement(req);
            ResultSet result=ste.executeQuery();
            
            while(result.next())
            {
            Travail a= new Travail (result.getInt("id_trav"),result.getInt("id_salle_trav")
                    ,result.getInt("id_centre_trav"),result.getInt("id_cab_trav"));
            list.add(a);
            }
           
       return list;
      }
}
