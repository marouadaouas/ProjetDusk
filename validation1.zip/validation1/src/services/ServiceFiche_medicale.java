/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;


import entites.Fiche_medicale;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.DataSource;

/**
 *
 * @author khoulouud
 */
public class ServiceFiche_medicale {
  public Connection con=DataSource.getInstance().getConnection();
    public Statement ste;
    
    
    public ServiceFiche_medicale(){
        try {
            ste=con.createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(ServiceTravail.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

   
public void AjouterFiche_medicale (Fiche_medicale a ) throws SQLException
    {
        String req="INSERT INTO `fiche_medicale`(`sexe`, `taille`, `poids`"
                + ", `groupe_sanguin`, `pression_arterielle`, `tabac`, `alcool`"
                + ", `date_naissance`, `IMC`, `respiration`, `temperature`, `allergie`, `id_fiche_user`)"
                + "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
        PreparedStatement pre= con.prepareStatement(req);
         //INSERT INTO `fiche_medicale`(`id_fiche`, `sexe`, 
    //`taille`, `poids`, `groupe_sanguin`, `pression_arterielle`, `tabac`, 
    //`alcool`, `date_naissance`, `IMC`, `respiration`, `temperature`, `allergie`, `id_fiche_user`
       
        pre.setString(1,a.getSexe());
        pre.setFloat(2,a.getTaille()); 
        pre.setFloat(3,a.getPoids());
        pre.setString(4,a.getGroupe_sanguin());
        pre.setFloat(5,a.getPression_arterielle());
        pre.setString(6,a.getTabac());
        pre.setString(7,a.getAlcool());
        pre.setDate(8,a.getDate_naissance());
        pre.setFloat(9,a.getIMC());
        pre.setFloat(10,a.getRespiration());
        pre.setFloat(11,a.getTemperature());
        pre.setString(12,a.getAllergie());
        pre.setInt(13,a.getId_fiche_user());
        
        
       
        pre.executeUpdate();
       
        
        System.out.println("fiche_medicale AjoutÃ©e");
        
    }
    
    
    public  void updateFiche_medicale(Fiche_medicale a,int id)throws SQLException
        {
                 String req = 
                         "UPDATE `fiche_medicale` SET `sexe`=?"
                         + ",`taille`=?,`poids`=? "
                         + ",`groupe_sanguin`=?,`pression_arterielle`=?"
                         + ",`tabac`=?,`alcool`=?,`date_naissance`=?,`IMC`=?"
                         + ",`respiration`=?,`temperature`=?,`allergie`=?"
                         + "where `id_fiche`=?";
                 PreparedStatement pre= con.prepareStatement(req);
                
                 
                pre.setString(1,a.getSexe());
                pre.setFloat(2,a.getTaille()); 
                pre.setFloat(3,a.getPoids());
                pre.setString(4,a.getGroupe_sanguin());
                pre.setFloat(5,a.getPression_arterielle());
                pre.setString(6,a.getTabac());
                pre.setString(7,a.getAlcool());
                pre.setDate(8,a.getDate_naissance());
                pre.setFloat(9,a.getIMC());
                pre.setFloat(10,a.getRespiration());
                pre.setFloat(11,a.getTemperature());
                pre.setString(12,a.getAllergie());
               // pre.setInt(13,a.getId_fiche_user());
                 pre.setInt(13,id);
                pre.executeUpdate();
                 System.out.println("fiche  mise Ã  jour"); 

}
    
    
    
    public  void supprimerFiche_medicale( int id) throws SQLException
        {
                 String req = "DELETE FROM `fiche_medicale` WHERE id_fiche="+id;
                 Statement pre=con.createStatement();
                 pre.executeUpdate(req);
                  System.out.println("Fiche_medicale SupprimÃ©e");
        }

    public  List<Fiche_medicale> selectFiche_medicale() throws SQLException
      {
       List<Fiche_medicale> list=new ArrayList<>();
         
            String req="SELECT * FROM fiche_medicale";
            PreparedStatement ste= con.prepareStatement(req);
            ResultSet result=ste.executeQuery();
         
                
            //SELECT `id_fiche`, `sexe`, `taille`, `poids`, `groupe_sanguin`, `pression_arterielle`, `tabac`, `alcool`
            //, `date_naissance`, `IMC`, `respiration`, `temperature`, `allergie`, `id_fiche_user` FROM `fiche_medicale`
            
            while(result.next())
            {
            Fiche_medicale a= new Fiche_medicale (result.getInt("id_fiche"),result.getString("sexe")
                    ,result.getFloat("taille"),result.getFloat("poids"),result.getString("groupe_sanguin")
                    ,result.getFloat("pression_arterielle"),result.getString("tabac"),result.getString("alcool")
                    ,result.getDate("date_naissance"),result.getFloat("IMC"),result.getFloat("respiration")
                    ,result.getFloat("temperature")
                    ,result.getString("allergie"),result.getInt("id_fiche_user")
            );
            list.add(a);
            }
           
       return list;
      }
    
    
    
    
    
    
    



}
