/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.util.Objects;

/**
 *
 * @author khoulouud
 */
public class Maladie {
    private int id_maladie;
    private String nom_maladie;
    private String description_maladie;
    private String traitement;

    public Maladie(int id_maladie, String nom_maladie, String description_maladie, String traitement) {
        this.id_maladie = id_maladie;
        this.nom_maladie = nom_maladie;
        this.description_maladie = description_maladie;
        this.traitement = traitement;
    }

    public Maladie(String nom_maladie, String description_maladie, String traitement) {
        this.nom_maladie = nom_maladie;
        this.description_maladie = description_maladie;
        this.traitement = traitement;
    }

    
    
    public int getId_maladie() {
        return id_maladie;
    }

    public void setId_maladie(int id_maladie) {
        this.id_maladie = id_maladie;
    }

    public String getNom_maladie() {
        return nom_maladie;
    }

    public void setNom_maladie(String nom_maladie) {
        this.nom_maladie = nom_maladie;
    }

    public String getDescription_maladie() {
        return description_maladie;
    }

    public void setDescription_maladie(String description_maladie) {
        this.description_maladie = description_maladie;
    }

    public String getTraitement() {
        return traitement;
    }

    public void setTraitement(String traitement) {
        this.traitement = traitement;
    }

    @Override
    public String toString() {
        return "Maladie{" + "id_maladie=" + id_maladie + ", nom_maladie=" + nom_maladie + ", description_maladie=" + description_maladie + ", traitement=" + traitement + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 79 * hash + this.id_maladie;
        hash = 79 * hash + Objects.hashCode(this.nom_maladie);
        hash = 79 * hash + Objects.hashCode(this.description_maladie);
        hash = 79 * hash + Objects.hashCode(this.traitement);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Maladie other = (Maladie) obj;
        if (this.id_maladie != other.id_maladie) {
            return false;
        }
        if (!Objects.equals(this.nom_maladie, other.nom_maladie)) {
            return false;
        }
        if (!Objects.equals(this.description_maladie, other.description_maladie)) {
            return false;
        }
        if (!Objects.equals(this.traitement, other.traitement)) {
            return false;
        }
        return true;
    }
    
    
    
    
}
