/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

/**
 *
 * @author khoulouud
 */
public class Travail {
    private int id_trav;
    private int id_salle_trav;
    private int id_centre_trav;
    private int id_cab_trav;

    public Travail(int id_salle_trav, int id_centre_trav, int id_cab_trav) {
        this.id_salle_trav = id_salle_trav;
        this.id_centre_trav = id_centre_trav;
        this.id_cab_trav = id_cab_trav;
    }

    
    public Travail(int id_trav, int id_salle_trav, int id_centre_trav, int id_cab_trav) {
        this.id_trav = id_trav;
        this.id_salle_trav = id_salle_trav;
        this.id_centre_trav = id_centre_trav;
        this.id_cab_trav = id_cab_trav;
    }

    public int getId_trav() {
        return id_trav;
    }

    public void setId_trav(int id_trav) {
        this.id_trav = id_trav;
    }

    public int getId_salle_trav() {
        return id_salle_trav;
    }

    public void setId_salle_trav(int id_salle_trav) {
        this.id_salle_trav = id_salle_trav;
    }

    public int getId_centre_trav() {
        return id_centre_trav;
    }

    public void setId_centre_trav(int id_centre_trav) {
        this.id_centre_trav = id_centre_trav;
    }

    public int getId_cab_trav() {
        return id_cab_trav;
    }

    public void setId_cab_trav(int id_cab_trav) {
        this.id_cab_trav = id_cab_trav;
    }

    @Override
    public String toString() {
        return "Travail{" + "id_trav=" + id_trav + ", id_salle_trav=" + id_salle_trav + ", id_centre_trav=" + id_centre_trav + ", id_cab_trav=" + id_cab_trav + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 67 * hash + this.id_trav;
        hash = 67 * hash + this.id_salle_trav;
        hash = 67 * hash + this.id_centre_trav;
        hash = 67 * hash + this.id_cab_trav;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Travail other = (Travail) obj;
        if (this.id_trav != other.id_trav) {
            return false;
        }
        if (this.id_salle_trav != other.id_salle_trav) {
            return false;
        }
        if (this.id_centre_trav != other.id_centre_trav) {
            return false;
        }
        if (this.id_cab_trav != other.id_cab_trav) {
            return false;
        }
        return true;
    }
    
    
}
