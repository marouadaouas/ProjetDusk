/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.util.Objects;

/**
 *
 * @author khoulouud
 */
public class Emploi {
    private int id_emploi;
    private String libelle;
    private int id_travail;
    private String description_travail;

    public Emploi(int id_emploi, String libelle, int id_travail, String description_travail) {
        this.id_emploi = id_emploi;
        this.libelle = libelle;
        this.id_travail = id_travail;
        this.description_travail = description_travail;
        
    }

    public Emploi(String libelle, int id_travail, String description_travail) {
        this.libelle = libelle;
        this.id_travail = id_travail;
        this.description_travail = description_travail;
    }

    
    
    
    public int getId_emploi() {
        return id_emploi;
    }

    public void setId_emploi(int id_emploi) {
        this.id_emploi = id_emploi;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public int getId_travail() {
        return id_travail;
    }

    public void setId_travail(int id_travail) {
        this.id_travail = id_travail;
    }

    public String getDescription_travail() {
        return description_travail;
    }

    public void setDescription_travail(String description_travail) {
        this.description_travail = description_travail;
    }

    @Override
    public String toString() {
        return "Emploi{" + "id_emploi=" + id_emploi + ", libelle=" + libelle + ", id_travail=" + id_travail + ", description_travail=" + description_travail + '}';
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 83 * hash + this.id_emploi;
        hash = 83 * hash + Objects.hashCode(this.libelle);
        hash = 83 * hash + this.id_travail;
        hash = 83 * hash + Objects.hashCode(this.description_travail);
        return hash;
    }

   

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Emploi other = (Emploi) obj;
        if (this.id_emploi != other.id_emploi) {
            return false;
        }
        if (this.id_travail != other.id_travail) {
            return false;
        }
        if (this.description_travail != other.description_travail) {
            return false;
        }
        if (!Objects.equals(this.libelle, other.libelle)) {
            return false;
        }
        return true;
    }
    
    
    
}
