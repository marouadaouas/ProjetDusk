/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.sql.Date;
import java.util.Objects;

/**
 *
 * @author khoulouud
 */
public class Fiche_medicale {
    	private int id_fiche;
        private String 	sexe;
        private float taille;
        private float poids;
        private String groupe_sanguin;
        private float pression_arterielle;
        private String 	tabac;
        private String 	alcool;
        private Date  date_naissance;
        private float IMC;
        private float respiration;
        private float temperature;
        private String allergie;
        private int id_fiche_user;

    public Fiche_medicale(int id_fiche, String sexe, float taille, float poids, String groupe_sanguin, float pression_arterielle, String tabac, String alcool, Date date_naissance, float IMC, float respiration, float temperature, String allergie, int id_fiche_user) {
        this.id_fiche = id_fiche;
        this.sexe = sexe;
        this.taille = taille;
        this.poids = poids;
        this.groupe_sanguin = groupe_sanguin;
        this.pression_arterielle = pression_arterielle;
        this.tabac = tabac;
        this.alcool = alcool;
        this.date_naissance = date_naissance;
        this.IMC = IMC;
        this.respiration = respiration;
        this.temperature = temperature;
        this.allergie = allergie;
        this.id_fiche_user = id_fiche_user;
    }

    public Fiche_medicale(String sexe, float taille, float poids, String groupe_sanguin, float pression_arterielle, String tabac, String alcool, Date date_naissance, float IMC, float respiration, float temperature, String allergie, int id_fiche_user) {
        this.sexe = sexe;
        this.taille = taille;
        this.poids = poids;
        this.groupe_sanguin = groupe_sanguin;
        this.pression_arterielle = pression_arterielle;
        this.tabac = tabac;
        this.alcool = alcool;
        this.date_naissance = date_naissance;
        this.IMC = IMC;
        this.respiration = respiration;
        this.temperature = temperature;
        this.allergie = allergie;
        this.id_fiche_user = id_fiche_user;
    }

    public Fiche_medicale(String sexe, float taille, float poids, String groupe_sanguin, float pression_arterielle, String tabac, String alcool, Date date_naissance, float IMC, float respiration, float temperature, String allergie) {
        this.sexe = sexe;
        this.taille = taille;
        this.poids = poids;
        this.groupe_sanguin = groupe_sanguin;
        this.pression_arterielle = pression_arterielle;
        this.tabac = tabac;
        this.alcool = alcool;
        this.date_naissance = date_naissance;
        this.IMC = IMC;
        this.respiration = respiration;
        this.temperature = temperature;
        this.allergie = allergie;
    }

    
    
    
    
    
    public int getId_fiche() {
        return id_fiche;
    }

    public void setId_fiche(int id_fiche) {
        this.id_fiche = id_fiche;
    }

    public String getSexe() {
        return sexe;
    }

    public void setSexe(String sexe) {
        this.sexe = sexe;
    }

    public float getTaille() {
        return taille;
    }

    public void setTaille(float taille) {
        this.taille = taille;
    }

    public float getPoids() {
        return poids;
    }

    public void setPoids(float poids) {
        this.poids = poids;
    }

    public String getGroupe_sanguin() {
        return groupe_sanguin;
    }

    public void setGroupe_sanguin(String groupe_sanguin) {
        this.groupe_sanguin = groupe_sanguin;
    }

    public float getPression_arterielle() {
        return pression_arterielle;
    }

    public void setPression_arterielle(float pression_arterielle) {
        this.pression_arterielle = pression_arterielle;
    }

    public String getTabac() {
        return tabac;
    }

    public void setTabac(String tabac) {
        this.tabac = tabac;
    }

    public String getAlcool() {
        return alcool;
    }

    public void setAlcool(String alcool) {
        this.alcool = alcool;
    }

    public Date getDate_naissance() {
        return date_naissance;
    }

    public void setDate_naissance(Date date_naissance) {
        this.date_naissance = date_naissance;
    }

    public float getIMC() {
        return IMC;
    }

    public void setIMC(float IMC) {
        this.IMC = IMC;
    }

    public float getRespiration() {
        return respiration;
    }

    public void setRespiration(float respiration) {
        this.respiration = respiration;
    }

    public float getTemperature() {
        return temperature;
    }

    public void setTemperature(float temperature) {
        this.temperature = temperature;
    }

    public String getAllergie() {
        return allergie;
    }

    public void setAllergie(String allergie) {
        this.allergie = allergie;
    }

    public int getId_fiche_user() {
        return id_fiche_user;
    }

    public void setId_fiche_user(int id_fiche_user) {
        this.id_fiche_user = id_fiche_user;
    }

    @Override
    public String toString() {
        return "Fiche{" + "id_fiche=" + id_fiche + ", sexe=" + sexe + ", taille=" + taille + ", poids=" + poids + ", groupe_sanguin=" + groupe_sanguin + ", pression_arterielle=" + pression_arterielle + ", tabac=" + tabac + ", alcool=" + alcool + ", date_naissance=" + date_naissance + ", IMC=" + IMC + ", respiration=" + respiration + ", temperature=" + temperature + ", allergie=" + allergie + ", id_fiche_user=" + id_fiche_user + '}';
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 17 * hash + this.id_fiche;
        hash = 17 * hash + Objects.hashCode(this.sexe);
        hash = 17 * hash + Float.floatToIntBits(this.taille);
        hash = 17 * hash + Float.floatToIntBits(this.poids);
        hash = 17 * hash + Objects.hashCode(this.groupe_sanguin);
        hash = 17 * hash + Float.floatToIntBits(this.pression_arterielle);
        hash = 17 * hash + Objects.hashCode(this.tabac);
        hash = 17 * hash + Objects.hashCode(this.alcool);
        hash = 17 * hash + Objects.hashCode(this.date_naissance);
        hash = 17 * hash + Float.floatToIntBits(this.IMC);
        hash = 17 * hash + Float.floatToIntBits(this.respiration);
        hash = 17 * hash + Float.floatToIntBits(this.temperature);
        hash = 17 * hash + Objects.hashCode(this.allergie);
        hash = 17 * hash + this.id_fiche_user;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Fiche_medicale other = (Fiche_medicale) obj;
        if (this.id_fiche != other.id_fiche) {
            return false;
        }
        if (Float.floatToIntBits(this.taille) != Float.floatToIntBits(other.taille)) {
            return false;
        }
        if (Float.floatToIntBits(this.poids) != Float.floatToIntBits(other.poids)) {
            return false;
        }
        if (Float.floatToIntBits(this.pression_arterielle) != Float.floatToIntBits(other.pression_arterielle)) {
            return false;
        }
        if (Float.floatToIntBits(this.IMC) != Float.floatToIntBits(other.IMC)) {
            return false;
        }
        if (Float.floatToIntBits(this.respiration) != Float.floatToIntBits(other.respiration)) {
            return false;
        }
        if (Float.floatToIntBits(this.temperature) != Float.floatToIntBits(other.temperature)) {
            return false;
        }
        if (this.id_fiche_user != other.id_fiche_user) {
            return false;
        }
        if (!Objects.equals(this.sexe, other.sexe)) {
            return false;
        }
        if (!Objects.equals(this.groupe_sanguin, other.groupe_sanguin)) {
            return false;
        }
        if (!Objects.equals(this.tabac, other.tabac)) {
            return false;
        }
        if (!Objects.equals(this.alcool, other.alcool)) {
            return false;
        }
        if (!Objects.equals(this.allergie, other.allergie)) {
            return false;
        }
        if (!Objects.equals(this.date_naissance, other.date_naissance)) {
            return false;
        }
        return true;
    }
        
        
        
        
        
        
}
